const quizData = [
  {
    question: "¿Qué disfrutás más?",
    answers: [
      { text: "Entender cómo funcionan las cosas", category: "tecnología" },
      { text: "Ayudar a otros con sus problemas", category: "social" },
      { text: "Diseñar cosas o usar tu creatividad", category: "arte" },
      { text: "Estar al aire libre y en contacto con la naturaleza", category: "campo" },
    ],
  },
  {
    question: "¿Qué preferís?",
    answers: [
      { text: "Un trabajo con computadoras", category: "tecnología" },
      { text: "Un rol donde escuchás a otros", category: "social" },
      { text: "Crear contenido o comunicar", category: "arte" },
      { text: "Trabajar en proyectos productivos o rurales", category: "campo" },
    ],
  },
];

let currentQuestion = 0;
const scores = {
  tecnología: 0,
  social: 0,
  arte: 0,
  campo: 0
};

function showQuestion() {
  const quiz = document.getElementById("quiz");
  quiz.innerHTML = "";
  const q = quizData[currentQuestion];
  const qElem = document.createElement("div");
  qElem.classList.add("question");
  qElem.innerHTML = "<h3>" + q.question + "</h3>";
  const answers = document.createElement("div");
  answers.classList.add("answers");
  q.answers.forEach((a, i) => {
    const label = document.createElement("label");
    label.innerHTML = `<input type='radio' name='answer' value='${a.category}'> ${a.text}`;
    answers.appendChild(label);
  });
  quiz.appendChild(qElem);
  quiz.appendChild(answers);
}

document.getElementById("nextBtn").addEventListener("click", () => {
  const checked = document.querySelector("input[name='answer']:checked");
  if (!checked) return;
  scores[checked.value]++;
  currentQuestion++;
  if (currentQuestion < quizData.length) {
    showQuestion();
  } else {
    showResult();
  }
});

function showResult() {
  document.getElementById("quiz").classList.add("hidden");
  document.getElementById("nextBtn").classList.add("hidden");
  const result = document.getElementById("result");
  result.classList.remove("hidden");
  const top = Object.keys(scores).reduce((a, b) => scores[a] > scores[b] ? a : b);
  let message = "";
  switch(top) {
    case "tecnología":
      message = "Te va lo digital. Podrías estudiar programación, ingeniería o algo tech.";
      break;
    case "social":
      message = "Tenés empatía. Carreras como psicología, docencia o trabajo social te van.";
      break;
    case "arte":
      message = "Tenés mucha creatividad. Diseño, comunicación, arte o música podrían ser lo tuyo.";
      break;
    case "campo":
      message = "Te gusta la producción, el aire libre. Agronomía, veterinaria o zootecnia te pueden interesar.";
      break;
  }
  result.innerHTML = `<h2>Resultado</h2><p>${message}</p>`;
}

showQuestion();